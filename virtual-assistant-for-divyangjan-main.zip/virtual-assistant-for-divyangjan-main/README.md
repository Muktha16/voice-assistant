# virtual-assistant-for-divyangjan
As a virtual assistant designed to help visually impaired people navigate around places and identify individuals in front of them.
